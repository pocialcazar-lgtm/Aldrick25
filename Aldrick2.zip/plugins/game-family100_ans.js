const similarity = require('similarity')
const threshold = 0.72

module.exports = {
    async before(m) {
        this.game = this.game || {}
        let id = 'family100_' + m.chat
        if (!(id in this.game)) return !0
        let room = this.game[id]
        if (!room) return !0

        let text = m.text.toLowerCase().replace(/[^\w\s\-]+/g, '')

        // Menyerah
        if (text === 'nyerah') {
            let allAnswers = room.jawaban.map((jawaban, index) => `(${index + 1}) ${jawaban}`).join('\n')
            this.reply(m.chat, `Permainan berakhir karena menyerah.\n\nJawaban yang benar:\n${allAnswers}`, room.msg)
            clearTimeout(room.timeout)
            delete this.game[id]
            return !0
        }

        // Cek apakah jawaban benar
        let index = room.jawaban.findIndex(j => j.toLowerCase() === text)
        if (index >= 0 && !room.terjawab[index]) {
            room.terjawab[index] = m.sender
            global.db.data.users[m.sender].money += room.rewardAmount

            let isWin = room.terjawab.every(v => v)
            let caption = `
*Soal:* ${room.soal}
Terdapat *${room.jawaban.length}* jawaban${room.jawaban.find(v => v.includes(' ')) ? ' (beberapa jawaban terdapat spasi)' : ''}

${isWin ? '*SEMUA JAWABAN TERJAWAB*\nSelamat, Anda telah menjawab semua jawaban dengan benar!' : ''}

${room.jawaban.map((j, i) => room.terjawab[i] ? `(${i + 1}) ${j} @${room.terjawab[i].split('@')[0]}` : false).filter(v => v).join('\n')}

+${room.rewardAmount} Money tiap jawaban benar
            `.trim()

            m.reply(caption, null, {
                contextInfo: {
                    mentionedJid: this.parseMention(caption)
                }
            }).then(msg => {
                this.game[id].msg = msg
            })

            if (isWin) {
                clearTimeout(room.timeout)
                delete this.game[id]
            }

            return !0
        }

        // Cek kemiripan
        let similarityMax = Math.max(...room.jawaban.map(j => similarity(j.toLowerCase(), text)))
       if (similarityMax >= threshold) {
    m.reply('Dikit lagi!')
    return false
}

return false
    }
}