// plugins/_sewa-check.js

const fs = require('fs')
const path = require('path')
const sewaPath = path.join(__dirname, '../database/sewa.json') // sesuaikan path

let sewaData = []
if (fs.existsSync(sewaPath)) {
  sewaData = JSON.parse(fs.readFileSync(sewaPath))
}

let handler = async (m, { conn, isOwner }) => {
  if (!m.isGroup || isOwner) return

  const sewa = sewaData.find(v => v.id === m.chat)
  if (!sewa) {
    return m.reply('❌ Bot belum diaktifkan di grup ini.\nSilakan hubungi owner untuk sewa.')
  }

  if (sewa.expired !== 'PERMANENT' && Date.now() > sewa.expired) {
    return m.reply('❌ Masa sewa bot di grup ini telah *habis!*\nSilakan hubungi owner untuk perpanjangan.')
  }
}

handler.all = true
module.exports = handler