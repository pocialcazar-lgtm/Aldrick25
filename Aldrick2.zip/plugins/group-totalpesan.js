let totalpesan = async (m, { conn }) => {
    if (!m.isGroup) throw '❌ Perintah ini hanya bisa digunakan di grup!'

    let groupID = m.chat
    let chats = db.data.chats[groupID] = db.data.chats[groupID] || {}
    chats.totalchat = chats.totalchat || {}

    // Ambil metadata grup & peserta
    let groupMetadata = await conn.groupMetadata(groupID)
    let participants = groupMetadata.participants || []
    let isAdmin = participants.find(p => p.id === m.sender)?.admin

    if (!isAdmin) throw '❌ Perintah ini hanya bisa digunakan oleh *Admin* grup!'

    // Hapus data user yang sudah keluar dari grup
    let idsInGroup = participants.map(p => p.id)
    for (let jid in chats.totalchat) {
        if (!idsInGroup.includes(jid)) delete chats.totalchat[jid]
    }

    // Gabungkan data semua member, walaupun belum pernah chat
    let merged = participants.map(p => {
        let jid = p.id
        let count = chats.totalchat[jid] || 0
        return [jid, count]
    })

    // Urutkan dari terbanyak ke nol chat
    merged.sort((a, b) => b[1] - a[1])

    if (merged.every(([, count]) => count === 0)) return m.reply('📭 Belum ada data chat tersimpan.')

    let totalChat = merged.reduce((sum, [, count]) => sum + count, 0)
    let totalMember = merged.length

    let cap = `📊 *Total chat: ${totalChat} dari ${totalMember} member*\n\n` +
        merged.map(([jid, count], i) => `${i + 1}. @${jid.split('@')[0]}: ${count} chat`).join('\n')

    await conn.reply(groupID, cap, m, {
        contextInfo: {
            mentionedJid: merged.map(([jid]) => jid)
        }
    })
}

// Auto rekam jumlah chat saat ada pesan grup
totalpesan.before = async function (m) {
    if (!m.isGroup || !m.sender) return
    let chat = db.data.chats[m.chat] = db.data.chats[m.chat] || {}
    chat.totalchat = chat.totalchat || {}
    chat.totalchat[m.sender] = (chat.totalchat[m.sender] || 0) + 1
}

totalpesan.help = ['totalpesan']
totalpesan.tags = ['group']
totalpesan.command = /^totalpesan$/i
totalpesan.group = true

module.exports = totalpesan