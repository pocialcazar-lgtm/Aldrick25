const axios = require('axios');

let handler = async (m, { conn, text, usedPrefix, command }) => {
  if (!text) throw `Contoh: ${usedPrefix + command} Soekarno`;

  try {
    let res = await axios.get(`https://id.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(text)}`);

    if (res?.data?.extract) {
      let hasil = `📚 *Wikipedia - ${res.data.title}*\n\n${res.data.extract}`;
      if (res.data.thumbnail?.source) {
        await conn.sendFile(m.chat, res.data.thumbnail.source, 'wikipedia.jpg', hasil, m);
      } else {
        m.reply(hasil);
      }
    } else {
      throw '❌ Artikel tidak ditemukan di Wikipedia.';
    }
  } catch (e) {
    throw '⚠️ Gagal mengambil data dari Wikipedia.\nPastikan kata kunci tidak mengandung simbol atau terlalu pendek.';
  }
};

handler.help = ['wikipedia <query>'];
handler.tags = ['search'];
handler.command = /^(wikipedia)$/i;
handler.limit = true;

module.exports = handler;