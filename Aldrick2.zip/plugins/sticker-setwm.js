let handler = async (m, { text, usedPrefix, command }) => {
    if (!text) throw `Contoh:\n${usedPrefix + command} StickerKu|BotKeren`;
    let [packname, author] = text.split('|');
    if (!packname || !author) throw `Format salah!\nContoh:\n${usedPrefix + command} StickerKu|BotKeren`;

    global.db.data.sticker = global.db.data.sticker || {};
    global.db.data.sticker.packname = packname.trim();
    global.db.data.sticker.author = author.trim();

    m.reply(`✅ Watermark disetel!\n• *Packname:* ${packname}\n• *Author:* ${author}`);
};

handler.help = ['setwm <packname|author>'];
handler.tags = ['owner'];
handler.command = /^setwm$/i;
handler.owner = true; // hanya bisa dilakukan oleh owner bot

module.exports = handler;