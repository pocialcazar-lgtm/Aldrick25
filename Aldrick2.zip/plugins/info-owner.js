/*
 * 📦 Plugin: info-owner.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * 🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
 * ⚠️ Jangan hapus watermark ini.
*/

let handler = async (m, { conn }) => {
  const name = global.nameowner || 'Owner Bot'
  const number = global.numberowner || '628xxx'
  const email = global.mail || 'example@gmail.com'
  const ig = global.instagram || 'https://instagram.com/username'
  const wm = global.wm || '© Bot WhatsApp'

  const teks = `*👑 INFO OWNER BOT*

📛 *Nama:* ${name}
📞 *Nomor:* wa.me/${number}
📧 *Email:* ${email}
🌐 *Instagram:* ${ig}

🏷️ *Powered by:* ${wm}`

  await conn.sendMessage(m.chat, {
    text: teks,
    footer: wm,
    buttons: [
      { buttonId: '.menu', buttonText: { displayText: '📜 MENU' }, type: 1 }
    ],
    headerType: 1 // tidak pakai gambar
  }, { quoted: m })
}

handler.help = ['owner']
handler.tags = ['info']
handler.command = /^(owner)$/i

module.exports = handler