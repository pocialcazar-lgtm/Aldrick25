let handler = async (m, { conn }) => {
  if (!m.isGroup) throw 'Fitur ini hanya bisa digunakan di grup.'
  
  let users = Object.entries(global.db.data.users)
  let warnList = users.filter(([jid, user]) => user.warn && user.warn > 0)

  if (!warnList.length) return m.reply('✅ Tidak ada pengguna yang memiliki peringatan.')

  let teks = `📋 *Daftar Pengguna yang Mendapat Peringatan*\n\n`
  for (let [jid, user] of warnList) {
    let name
    try {
      name = await conn.getName(jid)
    } catch {
      name = jid.split('@')[0]
    }
    teks += `• @${jid.split('@')[0]} → ${user.warn} warn\n`
  }

  m.reply(teks, null, {
    mentions: warnList.map(([jid]) => jid)
  })
}

handler.help = ['listwarn']
handler.tags = ['group']
handler.command = /^listwarn$/i
handler.group = true
handler.admin = true

module.exports = handler