let handler = async (m, { conn }) => {
  if (!m.isGroup) return m.reply('❌ Perintah ini hanya bisa digunakan di dalam grup.')

  // Cek apakah pengirim adalah owner
  const sender = m.sender
  const ownerList = global.owner.map(v => v + '@s.whatsapp.net')
  if (!ownerList.includes(sender)) {
    return m.reply('❌ Hanya owner bot yang bisa menggunakan perintah ini.')
  }

  await m.reply('👋 Bot akan keluar dari grup ini...')
  await conn.groupLeave(m.chat)
}

handler.help = ['leavegc']
handler.tags = ['owner']
handler.command = /^leavegc$/i
handler.owner = true // Boleh dipakai hanya oleh owner

module.exports = handler