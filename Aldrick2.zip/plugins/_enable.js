/*
 * 📦 Plugin: _enable.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * ⚠️ Jangan hapus watermark ini.
*/

let handler = async (m, { conn, usedPrefix, command, args, isROwner }) => {
  let isEnable = /true|enable|(turn)?on|1/i.test(command)
  let chat = global.db.data.chats[m.chat]
  let user = global.db.data.users[m.sender]
  let type = (args[0] || '').toLowerCase()
  let isAll = false
  let isUser = false

  switch (type) {
    case 'welcome': chat.welcome = isEnable; break
    case 'detect': chat.detect = isEnable; break
    case 'delete': chat.delete = isEnable; break
    case 'antidelete': chat.delete = !isEnable; break
    case 'autodelvn': chat.autodelvn = isEnable; break
    case 'antilink': chat.antiLink = isEnable; break
    case 'antilinkkick': chat.antilinkkick = isEnable; break
    case 'antilinknokick': chat.antilinknokick = isEnable; break
    case 'antibadwordkick': chat.antibadwordkick = isEnable; break
    case 'antibadwordnokick': chat.antibadwordnokick = isEnable; break
    case 'antiwamekick': chat.antiwamekick = isEnable; break
    case 'antiwamenokick': chat.antiwamenokick = isEnable; break
    case 'antisticker': chat.antiSticker = isEnable; break
    case 'autosticker': chat.stiker = isEnable; break
    case 'toxic': chat.antiToxic = !isEnable; break
    case 'antitoxic': chat.antiToxic = isEnable; break
    case 'viewonce': chat.viewonce = isEnable; break
    case 'autolevelup': user.autolevelup = isEnable; isUser = true; break
    case 'document': chat.useDocument = isEnable; break
    case 'antibot': chat.antibot = isEnable; break

    case 'public':
    case 'restrict':
    case 'nyimak':
    case 'autoread':
    case 'pconly':
    case 'gconly':
    case 'swonly':
      if (!isROwner) throw false
      global.opts[type] = isEnable
      isAll = true
      break

    default:
      if (!/[01]/.test(command)) {
        const status = v => v ? '✅' : '❌'
        const list = `
╭───❏ *DAFTAR FITUR & STATUS*
│ ${status(chat.welcome)} welcome
│ ${status(chat.detect)} detect
│ ${status(chat.delete)} delete / antidelete
│ ${status(chat.autodelvn)} autodelvn
│ ${status(chat.antiLink)} antilink
│ ${status(chat.antilinkkick)} antilinkkick
│ ${status(chat.antilinknokick)} antilinknokick
│ ${status(chat.antibadwordkick)} antibadwordkick
│ ${status(chat.antibadwordnokick)} antibadwordnokick
│ ${status(chat.antiwamekick)} antiwamekick
│ ${status(chat.antiwamenokick)} antiwamenokick
│ ${status(chat.antiSticker)} antisticker
│ ${status(chat.stiker)} autosticker
│ ${status(chat.antiToxic)} antitoxic
│ ${status(chat.useDocument)} document
│ ${status(chat.antibot)} antibot
│ ${status(chat.viewonce)} viewonce
│ ${status(user.autolevelup)} autolevelup
│ ${status(global.opts.public)} public
│ ${status(global.opts.restrict)} restrict
│ ${status(global.opts.nyimak)} nyimak
│ ${status(global.opts.autoread)} autoread
│ ${status(global.opts.pconly)} pconly
│ ${status(global.opts.gconly)} gconly
│ ${status(global.opts.swonly)} swonly
╰────❏
Contoh:
${usedPrefix}enable antiwamekick
${usedPrefix}disable antiwamenokick`.trim()
        return m.reply(list)
      }
      throw false
  }

  m.reply(`Fitur *${type}* berhasil di *${isEnable ? 'aktifkan ✅' : 'dinonaktifkan ❌'}*!`)
}

handler.help = ['enable <fitur>', 'disable <fitur>']
handler.tags = ['group', 'owner']
handler.command = /^((en|dis)able|(tru|fals)e|(turn)?o(n|ff)|[01])$/i

module.exports = handler