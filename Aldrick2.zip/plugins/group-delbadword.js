let handler = async (m, { conn, args, isAdmin, isOwner }) => {
  if (!m.isGroup) throw 'Fitur hanya untuk grup'
  if (!isAdmin && !isOwner) throw 'Hanya admin yang bisa menghapus kata'

  let word = args.join(' ').toLowerCase()
  if (!word) throw 'Masukkan kata yang ingin dihapus dari daftar kata kasar'

  let chat = global.db.data.chats[m.chat]
  chat.badwords = chat.badwords || []

  if (!chat.badwords.includes(word)) throw 'Kata tersebut tidak ada dalam daftar'

  chat.badwords = chat.badwords.filter(v => v !== word)
  m.reply(`✅ Berhasil menghapus kata: *${word}* dari daftar kata kasar`)
}

handler.help = ['delbadword <kata>']
handler.tags = ['group']
handler.command = /^delbadword$/i
handler.admin = true
handler.group = true

module.exports = handler