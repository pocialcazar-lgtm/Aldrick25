let handler = async (m, { conn }) => {
  let users = Object.entries(global.db.data.users)
    .filter(([_, data]) => data.ultah)
    .map(([jid, data]) => `• @${jid.split('@')[0]}: ${data.ultah}`)

  if (users.length == 0) throw 'Belum ada pengguna yang mengatur tanggal ulang tahun.'

  m.reply(`🎂 Daftar Ulang Tahun:\n\n${users.join('\n')}`, null, {
    mentions: users.map(u => u.match(/@(\d+)/)[0] + '@s.whatsapp.net')
  })
}

handler.help = ['listultah']
handler.tags = ['group']
handler.command = /^listultah$/i
handler.group = true

module.exports = handler