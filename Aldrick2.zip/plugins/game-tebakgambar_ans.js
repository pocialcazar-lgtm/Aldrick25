let poin = 10000
const threshold = 0.72

let handler = m => m

handler.before = async function (m) {
  if (!m.quoted || !m.quoted.text || !/Ketik.*hint/i.test(m.quoted.text)) return !0

  this.tebakgambar = this.tebakgambar || {}
  let id = m.chat
  if (!(id in this.tebakgambar)) return !0

  const soal = this.tebakgambar[id]
  const jawaban = soal[1].jawaban.toLowerCase().trim()
  const teksUser = m.text.toLowerCase().trim()

  if (teksUser === jawaban) {
    let user = global.db.data.users[m.sender]
    user.exp += soal[2]
    user.money += poin
    user.tiketcoin = (user.tiketcoin || 0) + 1
    m.reply(`✅ *Benar!*\n+${soal[2]} XP\n+${poin} 💰 Uang\n+1 🎟️ Tiket`)
    clearTimeout(soal[3])
    delete this.tebakgambar[id]
  } else {
    m.reply('❌ Salah!')
  }

  return !0
}

handler.exp = 0
module.exports = handler