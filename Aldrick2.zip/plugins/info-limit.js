let handler = async (m, { conn, text }) => {
    let who

    if (m.isGroup) {
        who = m.mentionedJid?.[0] || m.sender
    } else {
        who = m.sender
    }

    let user = global.db.data.users[who]
    if (!user) throw '❌ Data pengguna tidak ditemukan.'

    const limit = user.limit || 0

    const fdoc = {
        key: {
            remoteJid: 'status@broadcast',
            participant: '0@s.whatsapp.net'
        },
        message: {
            documentMessage: {
                title: global.setinfo?.wm || 'Bot Info'
            }
        }
    }

    await conn.reply(m.chat, `📊 @${who.split('@')[0]} memiliki *${limit}* limit tersisa.`, m, {
        mentions: [who],
        quoted: fdoc
    })
}

handler.help = ['limit [@user]']
handler.tags = ['info']
handler.command = /^limit$/i

module.exports = handler