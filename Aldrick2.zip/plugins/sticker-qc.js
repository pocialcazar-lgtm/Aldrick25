const axios = require('axios');

const handler = async (m, { conn, args, command, usedPrefix, text }) => {
    if (!text) {
        return conn.reply(m, `Contoh penggunaan: ${usedPrefix + command} pink Halo Dunia`);
    }
    let [colorInput, ...messageParts] = text.split(' ');
    let message = messageParts.join(' ')
    if (!message) {
        message = colorInput + (messageParts.length ? ' ' + messageParts.join(' ') : '');
        colorInput = 'white'
    }

    let backgroundColor;
    switch (colorInput.toLowerCase()) {
        case 'pink': backgroundColor = '#f68ac9'; break;
        case 'blue': backgroundColor = '#6cace4'; break;
        case 'red': backgroundColor = '#f44336'; break;
        case 'green': backgroundColor = '#4caf50'; break;
        case 'yellow': backgroundColor = '#ffeb3b'; break;
        case 'purple': backgroundColor = '#9c27b0'; break;
        case 'darkblue': backgroundColor = '#0d47a1'; break;
        case 'lightblue': backgroundColor = '#03a9f4'; break;
        case 'ash': backgroundColor = '#9e9e9e'; break;
        case 'orange': backgroundColor = '#ff9800'; break;
        case 'black': backgroundColor = '#000000'; break;
        case 'white': backgroundColor = '#ffffff'; break;
        case 'teal': backgroundColor = '#008080'; break;
        case 'lightpink': backgroundColor = '#FFC0CB'; break;
        case 'chocolate': backgroundColor = '#A52A2A'; break;
        case 'salmon': backgroundColor = '#FFA07A'; break;
        case 'magenta': backgroundColor = '#FF00FF'; break;
        case 'tan': backgroundColor = '#D2B48C'; break;
        case 'wheat': backgroundColor = '#F5DEB3'; break;
        case 'deeppink': backgroundColor = '#FF1493'; break;
        case 'fire': backgroundColor = '#B22222'; break;
        case 'skyblue': backgroundColor = '#00BFFF'; break;
        case 'brightskyblue': backgroundColor = '#1E90FF'; break;
        case 'hotpink': backgroundColor = '#FF69B4'; break;
        case 'lightskyblue': backgroundColor = '#87CEEB'; break;
        case 'seagreen': backgroundColor = '#20B2AA'; break;
        case 'darkred': backgroundColor = '#8B0000'; break;
        case 'orangered': backgroundColor = '#FF4500'; break;
        case 'cyan': backgroundColor = '#48D1CC'; break;
        case 'violet': backgroundColor = '#BA55D3'; break;
        case 'mossgreen': backgroundColor = '#00FF7F'; break;
        case 'darkgreen': backgroundColor = '#008000'; break;
        case 'navyblue': backgroundColor = '#191970'; break;
        case 'darkorange': backgroundColor = '#FF8C00'; break;
        case 'darkpurple': backgroundColor = '#9400D3'; break;
        case 'fuchsia': backgroundColor = '#FF00FF'; break;
        case 'darkmagenta': backgroundColor = '#8B008B'; break;
        case 'darkgray': backgroundColor = '#2F4F4F'; break;
        case 'peachpuff': backgroundColor = '#FFDAB9'; break;
        case 'darkishgreen': backgroundColor = '#BDB76B'; break;
        case 'darkishred': backgroundColor = '#DC143C'; break;
        case 'goldenrod': backgroundColor = '#DAA520'; break;
        case 'darkishgray': backgroundColor = '#696969'; break;
        case 'darkishpurple': backgroundColor = '#483D8B'; break;
        case 'gold': backgroundColor = '#FFD700'; break;
        case 'silver': backgroundColor = '#C0C0C0'; break;
        default:
            backgroundColor = '#ffffff'; // default putih kalau warna tidak valid
            message = colorInput + (messageParts.length ? ' ' + messageParts.join(' ') : '');
            console.log('Cek 6: Warna tidak valid, pakai default putih');
    }



    const pp = await conn.profilePictureUrl(m.sender, 'image').catch(() =>
        'https://cdn.pixabay.com/photo/2015/10/05/22/37/blank-profile-picture-973460_960_720.png?q=60'
    );

    const obj = {
        type: 'quote',
        format: 'png',
        backgroundColor,
        width: 512,
        height: 768,
        scale: 2,
        messages: [{
            entities: [],
            avatar: true,
            from: {
                id: 1,
                name: m.pushName || "Pengguna",
                photo: { url: pp }
            },
            text: message,
            replyMessage: {}
        }]
    };

    try {
        const res = await axios.post('https://bot.lyo.su/quote/generate', obj, {
            headers: { 'Content-Type': 'application/json' }
        });
        const buffer = Buffer.from(res.data.result.image, 'base64');
        await conn.sendImageAsSticker(m.chat, buffer, m, {
            packname: global.packname,
            author: global.author
        });

    } catch (e) {
        console.error('Gagal membuat stiker:', e);
        conn.reply(m, "Gagal membuat stiker.");
    }
};

handler.command = /^(qc|quotly)$/i;
handler.register = true
handler.limit = true
module.exports = handler;