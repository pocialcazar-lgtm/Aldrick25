let handler = async (m, { conn, args, usedPrefix, command }) => {
  let user = global.db.data.users[m.sender]
  let tanggal = args[0]

  if (!tanggal) throw `Masukkan tanggal ulang tahun kamu!\nContoh: *${usedPrefix + command} 23-07-2005*`

  if (!/^\d{2}-\d{2}-\d{4}$/.test(tanggal)) throw `Format tanggal salah!\nGunakan format: *dd-mm-yyyy*\nContoh: *${usedPrefix + command} 23-07-2005*`

  user.ultah = tanggal
  m.reply(`✅ Tanggal ulang tahun kamu telah disimpan: *${tanggal}*`)
}

handler.help = ['ultahku <tgl-bln-thn>']
handler.tags = ['group']
handler.command = /^ultahku$/i

module.exports = handler