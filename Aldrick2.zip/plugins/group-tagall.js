let handler = async (m, { conn, text, participants }) => {
  let senderTag = '@' + m.sender.split('@')[0];
  let pesanUtama = text ? text : 'Tidak ada pesan yang disampaikan.';

  // Ambil metadata grup
  let groupMetadata = await conn.groupMetadata(m.chat);
  let groupName = groupMetadata.subject;

  // Ambil semua admin
  const groupAdmins = participants
    .filter(p => p.admin)
    .map(p => p.id);

  const adminTags = groupAdmins.map(admin => '│  🛡️ @' + admin.split('@')[0]).join('\n');
  const mentionAll = participants.map(p => '│  @' + p.id.split('@')[0]).join('\n');

  let teks = `
╭───❖「 *📢 PENGUMUMAN GRUP* 」❖───╮
│
│  *🗣️ Pesan dari Admin:* 
│  ${pesanUtama.split('\n').map(line => '│  ' + line).join('\n')}
│
│  *📍 Dikirim oleh:* ${senderTag}
│
│  *🛡️ Admin Grup:*
${adminTags}
│
│  *👥 Anggota Grup:*
${mentionAll}
│
╰───❖「 *${groupName}* 」❖───╯
`.trim();

  // Mention semua anggota, admin, dan pengirim
  let mentions = [...new Set([...participants.map(p => p.id), ...groupAdmins, m.sender])];

  await conn.sendMessage(m.chat, {
    text: teks,
    mentions
  });
};

handler.help = ['tagall <pesan>'];
handler.tags = ['group'];
handler.command = /^tagall$/i;

handler.group = true;
handler.admin = true;

module.exports = handler;