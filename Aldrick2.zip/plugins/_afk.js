let handler = m => m;

handler.before = m => {
  let user = global.db.data.users[m.sender];
  global.db.data.afkResponCooldown = global.db.data.afkResponCooldown || {};

  // Jika user sedang AFK dan melakukan aktivitas
  if (user.afk > -1) {
    m.reply(`
🔔 *AFK Dibatalkan*
Kamu tidak lagi dalam mode AFK${user.afkReason ? ` (Alasan: ${user.afkReason})` : ''}.
⏱️ Durasi AFK: *${clockString(new Date - user.afk)}*
    `.trim());
    user.afk = -1;
    user.afkReason = '';
  }

  // Deteksi mention user yang sedang AFK
  let jids = [...new Set([...(m.mentionedJid || []), ...(m.quoted ? [m.quoted.sender] : [])])];
  let now = +new Date();

  for (let jid of jids) {
    if (jid === m.sender) continue; // ⛔ Jangan balas kalau yang tag dirinya sendiri
    if (m.isBaileys) continue;

    let afkUser = global.db.data.users[jid];
    if (!afkUser) continue;

    let afkTime = afkUser.afk;
    if (!afkTime || afkTime < 0) continue;

    if (now - afkTime < 3000) continue; // Jika AFK baru aktif, skip

    if (global.db.data.afkResponCooldown[jid] && now - global.db.data.afkResponCooldown[jid] < 10000) continue;
    global.db.data.afkResponCooldown[jid] = now;

    let reason = afkUser.afkReason || 'Tidak ada alasan';
    m.reply(`
📛 *Jangan Tag Dulu*
Pengguna @${jid.split('@')[0]} sedang AFK.
📋 Alasan: ${reason}
⏱️ Sejak: *${clockString(now - afkTime)}*
    `.trim(), false, { mentions: [jid] });
  }

  return true;
};

module.exports = handler;

// Fungsi durasi
function clockString(ms) {
  let h = isNaN(ms) ? '--' : Math.floor(ms / 3600000);
  let m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
  let s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
  return [h, m, s].map(v => v.toString().padStart(2, 0)).join(':');
}