let defaultBadwords = [
  'anjing', 'goblok', 'babi', 'kontol', 'memek', 'bangsat', 'tolol', 'ngentot', 'pepek',
  'peler', 'asw', 'kampret', 'kimak', 'idiot', 'setan', 'tai', 'kntl'
]

module.exports = {
  async before(m, { conn, isBotAdmin, isAdmin }) {
    if (!m.isGroup || m.fromMe || m.isBaileys) return

    let chat = global.db.data.chats[m.chat]
    let text = (m.text || '').toLowerCase()
    let customBadwords = chat.badwords || []

    let allBadwords = [...new Set([...defaultBadwords, ...customBadwords])]

    if (chat.antibadwordkick || chat.antibadwordnokick) {
      let found = allBadwords.some(word => text.includes(word))
      if (found) {
        if (chat.antibadwordkick) {
          if (isBotAdmin && !isAdmin) {
            await conn.reply(m.chat, `⚠️ *Kata kasar terdeteksi!*\n@${m.sender.split('@')[0]} akan dikeluarkan.`, m, { mentions: [m.sender] })
            await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
          }
        } else if (chat.antibadwordnokick) {
          await conn.reply(m.chat, `⚠️ Kata kasar terdeteksi!\n@${m.sender.split('@')[0]}, jaga ucapanmu!`, m, { mentions: [m.sender] })
        }
      }
    }
  }
}