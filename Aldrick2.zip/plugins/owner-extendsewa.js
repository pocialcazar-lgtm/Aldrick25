let handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!m.isGroup) throw '❌ Fitur ini hanya untuk grup.'
  if (!args[0]) throw `Masukkan jumlah hari atau ketik *permanent*\nContoh:\n${usedPrefix + command} 7\n${usedPrefix + command} permanent`

  let chat = global.db.data.chats[m.chat]
  let now = new Date() * 1
  let input = args[0].toLowerCase()

  if (input === 'permanent') {
    chat.expired = 0
    return m.reply('✅ Masa sewa grup ini telah diperpanjang menjadi *PERMANEN*.')
  }

  if (isNaN(args[0])) throw 'Masukkan angka hari yang valid atau tulis *permanent*!'

  let tambah = 86400000 * Number(args[0])

  if (!chat.expired || chat.expired < now) {
    chat.expired = now + tambah
  } else if (chat.expired == 0) {
    return m.reply('⛔ Grup ini sudah permanen. Tidak bisa diperpanjang lagi.')
  } else {
    chat.expired += tambah
  }

  let sisa = chat.expired - now
  m.reply(`✅ Masa sewa grup berhasil diperpanjang ${args[0]} hari.\n📆 Sisa waktu: ${msToDate(sisa)}`)
}

handler.help = ['extendsewa <jumlah hari|permanent>']
handler.tags = ['owner']
handler.command = /^extendsewa$/i
handler.owner = true

module.exports = handler

function msToDate(ms) {
  let days = Math.floor(ms / (24 * 60 * 60 * 1000))
  let daysms = ms % (24 * 60 * 60 * 1000)
  let hours = Math.floor(daysms / (60 * 60 * 1000))
  let hoursms = ms % (60 * 60 * 1000)
  let minutes = Math.floor(hoursms / (60 * 1000))
  return `${days} hari ${hours} jam ${minutes} menit`
}