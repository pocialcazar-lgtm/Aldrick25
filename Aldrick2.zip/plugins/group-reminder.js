const fs = require('fs')
const path = './database/reminder.json'
let reminders = fs.existsSync(path) ? JSON.parse(fs.readFileSync(path)) : []

let handler = async (m, { command, args, text, conn }) => {
  const chat = m.chat

  if (command === 'addreminder') {
    if (!text.includes('|')) return m.reply(`📌 Format salah!\nContoh: .addreminder belajar|14.30wib|25-07-2025`)
    
    let [pesan, jamStr, tanggalStr] = text.split('|').map(a => a.trim())
    if (!pesan || !jamStr || !tanggalStr) return m.reply('❗ Format tidak lengkap.')

    let zona = jamStr.toLowerCase().includes('wit') ? '+09:00' :
               jamStr.toLowerCase().includes('wita') ? '+08:00' : '+07:00'
    let zonaLabel = zona === '+09:00' ? 'WIT' : zona === '+08:00' ? 'WITA' : 'WIB'

    let [jam, menit] = jamStr.replace(/(wib|wita|wit)/gi, '').split('.')
    let [dd, mm, yyyy] = tanggalStr.split('-')
    if (!jam || !menit || !dd || !mm || !yyyy) return m.reply('❗ Format jam atau tanggal salah.')

    let waktu = new Date(`${yyyy}-${mm}-${dd}T${jam}:${menit}:00${zona}`)
    if (isNaN(waktu)) return m.reply('❌ Waktu tidak valid.')
    if (waktu < new Date()) return m.reply('⏳ Waktu sudah lewat.')

    reminders.push({
      chat,
      pesan,
      waktu: waktu.getTime(),
      zona
    })

    fs.writeFileSync(path, JSON.stringify(reminders))
    return m.reply(`✅ Reminder ditambahkan!\n📌 ${pesan}\n🕒 ${jam}:${menit} ${zonaLabel}\n📅 ${dd}-${mm}-${yyyy}`)
  }

  if (command === 'listreminder') {
    let list = reminders.filter(r => r.chat === chat)
    if (!list.length) return m.reply('📭 Tidak ada reminder di grup ini.')

    let teks = list.map((r, i) => {
      let zona = r.zona === '+09:00' ? 'Asia/Jayapura' : r.zona === '+08:00' ? 'Asia/Makassar' : 'Asia/Jakarta'
      let time = new Date(r.waktu).toLocaleString('id-ID', { timeZone: zona })
      return `*${i + 1}.* ${r.pesan}\n⏰ ${time}`
    }).join('\n\n')

    return m.reply(`📋 *Daftar Reminder:*\n\n${teks}`)
  }

  if (command === 'delreminder') {
    let index = parseInt(text) - 1
    if (isNaN(index)) return m.reply('❗ Contoh: .delreminder 1')

    let list = reminders.filter(r => r.chat === chat)
    if (!list[index]) return m.reply('❌ Index tidak ditemukan.')

    let globalIndex = reminders.indexOf(list[index])
    reminders.splice(globalIndex, 1)
    fs.writeFileSync(path, JSON.stringify(reminders))
    return m.reply('🗑️ Reminder berhasil dihapus.')
  }
}

handler.help = ['addreminder <pesan>|<jam>wib|<dd-mm-yyyy>', 'listreminder', 'delreminder <no>']
handler.tags = ['group']
handler.command = /^addreminder|listreminder|delreminder$/i
handler.group = true
handler.admin = true

module.exports = handler

// === Notifikasi Otomatis ===
setInterval(async () => {
  let now = Date.now()
  let due = reminders.filter(r => now >= r.waktu)
  for (let r of due) {
    let zona = r.zona === '+09:00' ? 'Asia/Jayapura' : r.zona === '+08:00' ? 'Asia/Makassar' : 'Asia/Jakarta'
    let waktuStr = new Date(r.waktu).toLocaleString('id-ID', { timeZone: zona })

    global.conn?.sendMessage?.(r.chat, {
      text: `📣 *Reminder!*\n\n🕒 ${waktuStr}\n📌 ${r.pesan}`
    })
  }
  // Hapus yang sudah dikirim
  if (due.length > 0) {
    reminders = reminders.filter(r => now < r.waktu)
    fs.writeFileSync(path, JSON.stringify(reminders))
  }
}, 30_000)