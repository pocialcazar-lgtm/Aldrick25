let handler = async (m, { conn, text, isROwner, isOwner }) => {
  if (!m.isGroup) throw '❌ Fitur ini hanya dapat digunakan di dalam grup.'

  if (!text) {
    throw `Kirim perintah dengan format:\n\n.setbye <teks>\n\nKeterangan:\n@user → Mention yang keluar\n\nContoh:\n.setbye Selamat tinggal @user, semoga sukses di luar sana!`
  }

  // Simpan pesan bye
  const chat = global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}

  if (isROwner) global.conn.bye = text
  else if (isOwner) conn.bye = text

  chat.sBye = text

  m.reply(`✅ Pesan bye berhasil diatur!\n\nGunakan format:\n@user → Mention member yang keluar`)
}

handler.help = ['setleft <teks>']
handler.tags = ['owner', 'group']
handler.command = /^setleft$/i
handler.botAdmin = true
handler.group = true
handler.admin = true // hanya admin grup yang bisa set

module.exports = handler