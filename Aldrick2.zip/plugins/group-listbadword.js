let handler = async (m, { conn }) => {
  if (!m.isGroup) throw 'Fitur ini hanya bisa digunakan di grup'

  let chat = global.db.data.chats[m.chat]
  chat.badwords = chat.badwords || []

  if (chat.badwords.length === 0) {
    return m.reply('📭 Tidak ada kata kasar yang ditambahkan dalam grup ini.')
  }

  let list = chat.badwords.map((word, i) => `${i + 1}. ${word}`).join('\n')
  m.reply(`📃 *Daftar Badword Grup Ini:*\n\n${list}`)
}

handler.help = ['listbadword']
handler.tags = ['group']
handler.command = /^listbadword$/i
handler.group = true

module.exports = handler