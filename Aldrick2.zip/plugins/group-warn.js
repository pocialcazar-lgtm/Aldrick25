let handler = async (m, { conn, args, usedPrefix, command, isAdmin, isBotAdmin }) => {
  if (!m.isGroup) throw 'Fitur ini hanya untuk grup.'
  if (!isAdmin) throw 'Fitur ini hanya bisa digunakan oleh admin grup.'
  if (!isBotAdmin) throw 'Bot harus menjadi admin.'

  const warnLimit = global.db.data.chats[m.chat].maxwarn || 3
  const user = m.mentionedJid[0] || m.quoted?.sender

  if (!user) throw `Tag pengguna dengan format:\n${usedPrefix + command} @user`

  global.db.data.users[user].warn = global.db.data.users[user].warn || 0

  if (command === 'warn') {
    global.db.data.users[user].warn++
    if (global.db.data.users[user].warn >= warnLimit) {
      await m.reply(`⚠️ Pengguna @${user.split('@')[0]} telah mencapai batas peringatan (${warnLimit}) dan akan dikeluarkan.`, null, { mentions: [user] })
      await conn.groupParticipantsUpdate(m.chat, [user], 'remove')
      global.db.data.users[user].warn = 0
    } else {
      m.reply(`⚠️ Peringatan untuk @${user.split('@')[0]}: ${global.db.data.users[user].warn}/${warnLimit}`, null, { mentions: [user] })
    }
  }

  if (command === 'cekwarn') {
    m.reply(`⚠️ Peringatan untuk @${user.split('@')[0]}: ${global.db.data.users[user].warn || 0}/${warnLimit}`, null, { mentions: [user] })
  }

  if (command === 'delwarn') {
    global.db.data.users[user].warn = 0
    m.reply(`✅ Peringatan untuk @${user.split('@')[0]} telah dihapus.`, null, { mentions: [user] })
  }
}

handler.help = ['warn @user', 'cekwarn @user', 'delwarn @user']
handler.tags = ['group']
handler.command = /^(warn|cekwarn|delwarn)$/i
handler.admin = true
handler.group = true

module.exports = handler