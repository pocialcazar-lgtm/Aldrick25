module.exports = {
  async before(m, { isAdmin, isOwner }) {
    if (!m.isGroup) return

    let chat = global.db.data.chats[m.chat] = global.db.data.chats[m.chat] || {}
    chat.mutedUsers = chat.mutedUsers || []

    // Jika user sedang di-mute dan bukan admin
    if (chat.mutedUsers.includes(m.sender) && !isAdmin && !isOwner) {
      return !1 // Jangan teruskan ke plugin lain
    }
  }
}