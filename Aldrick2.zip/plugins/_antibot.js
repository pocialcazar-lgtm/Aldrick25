module.exports = {
  before: async function (m, { conn, participants }) {
    if (!m.isGroup) return
    let chat = global.db.data.chats[m.chat]
    if (!chat.antibot) return

    if (!m.sender.endsWith('@s.whatsapp.net')) return
    if (m.isBaileys || m.key.id.startsWith('BAE') || m.key.id.startsWith('3EB0') || m.key.id.startsWith('B1E') || m.key.id.startsWith('WA')) {
      let senderId = m.sender
      let isBot = participants.find(p => p.id === senderId && p.isAdmin === undefined) // jika dia bot, biasanya tidak ada `isAdmin` atau bukan member normal
      let isBotAdmin = participants.find(p => p.id === conn.user.jid)?.admin
      if (!m.fromMe && !isBotAdmin) {
        await conn.sendMessage(m.chat, {
          text: `*[🚨 Sistem Deteksi Bot]*\nTerdeteksi Bot asing (@${senderId.split('@')[0]})!\nAkan dikeluarkan dari grup.`,
          mentions: [senderId]
        })
        await conn.groupParticipantsUpdate(m.chat, [senderId], 'remove').catch(console.error)
      }
    }
  }
}