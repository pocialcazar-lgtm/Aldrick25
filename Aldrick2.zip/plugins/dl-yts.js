const yts = require('yt-search')

let handler = async (m, { text, command }) => {
  if (!text) return m.reply(`Contoh: .${command} duka`)
  let search = await yts(text)
  let results = search.all.slice(0, 8)

  if (!results.length) return m.reply('❌ Tidak ditemukan hasil.')

  let teks = `📌 *Hasil pencarian YouTube:*\n\n`
  teks += results.map(v => {
    let title = v.title || '-'
    let url = v.url || '-'
    let waktu = v.timestamp || '-'
    let author = v.author?.name || '-'
    return `• ${title}\n📺 ${author}\n🕐 ${waktu}\n🔗 ${url}\n`
  }).join('\n')

  m.reply(teks)
}

handler.help = ['yts <pencarian>']
handler.tags = ['downloader']
handler.command = /^yts$/i

module.exports = handler