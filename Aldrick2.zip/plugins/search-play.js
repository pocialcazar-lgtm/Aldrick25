/*
 * 📦 Plugin: dl-play.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * 🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
 * ⚠️ Jangan hapus watermark ini.
*/

const fetch = require('node-fetch')

const handler = async (m, { conn, args, usedPrefix, command }) => {
  if (!args[0]) return m.reply(`🚫 Contoh penggunaan:\n${usedPrefix + command} someone like you`)

  try {
    const query = args.join(' ')
    m.reply('🔍 Mencari lagu...')

    const apiUrl = `https://izumi-apis.zone.id/downloader/play?query=${encodeURIComponent(query)}`
    const res = await fetch(apiUrl)
    const json = await res.json()

    if (!json.status || !json.result) return m.reply('🚫 Lagu tidak ditemukan.')

    const video = json.result.metadata
    const downloadUrl = json.result.downloads

    // Unduh audio
    const fileRes = await fetch(downloadUrl)
    if (!fileRes.ok) throw '🚫 Gagal mengunduh audio dari server.'
    const buffer = Buffer.from(await fileRes.arrayBuffer())

    // Kirim audio langsung, tanpa caption tambahan
    await conn.sendMessage(m.chat, {
      audio: buffer,
      fileName: `${video.title}.mp3`,
      mimetype: 'audio/mpeg',
      ptt: false,
      contextInfo: {
        externalAdReply: {
          title: video.title,
          body: video.author.name,
          thumbnailUrl: video.thumbnail,
          sourceUrl: json.result.url,
          mediaType: 1,
          renderLargerThumbnail: true
        }
      }
    }, { quoted: m })

  } catch (err) {
    console.error('[ERROR .play]', err)
    m.reply(`🚫 Terjadi kesalahan saat mengambil audio.\n\n${err?.message || err}`)
  }
}

handler.help = ['play <judul>']
handler.tags = ['search']
handler.command = /^play$/i

module.exports = handler