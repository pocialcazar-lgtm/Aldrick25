const fs = require('fs')
const path = require('path')
const moment = require('moment')

const dir = './database'
const file = path.join(dir, 'sewa.json')

let handler = async (m, { conn }) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir)
  if (!fs.existsSync(file)) fs.writeFileSync(file, '[]')

  const data = JSON.parse(fs.readFileSync(file))
  if (data.length === 0) return m.reply('📭 Tidak ada grup yang sedang sewa bot.')

  let teks = '📋 *DAFTAR GRUP SEWA BOT*\n\n'
  const now = Date.now()
  let count = 1

  for (let sewa of data) {
    let status = ''
    let sisa = ''
    let name = '(Tidak diketahui)'

    try {
      const metadata = await conn.groupMetadata(sewa.id)
      name = metadata.subject || '(Tanpa nama)'
    } catch (e) {
      // Bot bukan member grup tsb, skip error
    }

    if (sewa.expired === 'PERMANENT') {
      status = '🟢 Aktif'
      sisa = '∞ Permanent'
    } else if (sewa.expired > now) {
      status = '🟢 Aktif'
      const duration = moment.duration(sewa.expired - now)
      sisa = `${duration.days()} hari ${duration.hours()} jam`
    } else {
      status = '🔴 Expired'
      sisa = 'Kadaluarsa'
    }

    teks += `${count++}. *${name}* (ID: ${sewa.id})\n• Status: ${status}\n• Sisa: ${sisa}\n\n`
  }

  m.reply(teks.trim())
}

handler.command = /^listsewa$/i
handler.owner = true
module.exports = handler