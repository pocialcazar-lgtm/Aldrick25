let handler = async (m, { conn }) => {
  conn.tebakgambar = conn.tebakgambar || {}
  let id = m.chat

  if (!(id in conn.tebakgambar)) {
    return m.reply('❌ Tidak ada soal aktif.\nKetik *.tebakgambar* untuk memulai.')
  }

  let jawaban = conn.tebakgambar[id][1].jawaban.toLowerCase().trim()
  let chars = jawaban.split('')
  let clue = ''

  // Tentukan berapa banyak huruf yang ditampilkan
  let visibleCount = Math.max(1, Math.floor(chars.length / 3))
  let visibleIndexes = []

  while (visibleIndexes.length < visibleCount) {
    let rand = Math.floor(Math.random() * chars.length)
    if (!visibleIndexes.includes(rand)) visibleIndexes.push(rand)
  }

  for (let i = 0; i < chars.length; i++) {
    clue += visibleIndexes.includes(i) ? chars[i] : '_'
  }

  let teks = `🕵️ *HINT*\nJawaban terdiri dari *${jawaban.length} huruf*.\n\n💡 Clue: *${clue.toUpperCase()}*`
  m.reply(teks)
}

handler.tags = ['game']
handler.command = /^hint$/i

module.exports = handler