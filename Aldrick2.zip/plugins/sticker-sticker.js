/*
 * 📦 Plugin: sticker-sticker.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * 🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
 * ⚠️ Jangan hapus watermark ini.
 * 📌 Untuk mengubah watermark, gunakan perintah: *.setwm*
*/

const fs = require('fs');

let handler = async (m, { conn, command, usedPrefix }) => {
    let q = m.quoted ? m.quoted : m;
    let mime = (q.msg || q).mimetype || '';

    // Ambil WM dari DB (gunakan .setwm untuk ubah)
    let stickerInfo = global.db.data.sticker || {};
    let packname = stickerInfo.packname || 'Sticker';
    let author = stickerInfo.author || 'Bot';

    if (/image/.test(mime)) {
        m.reply('⏳ Sedang membuat stiker...');
        let media = await q.download();
        let encmedia = await conn.sendImageAsSticker(m.chat, media, m, {
            packname,
            author
        });
        await fs.unlinkSync(encmedia);

    } else if (/video/.test(mime)) {
        if ((q.msg || q).seconds > 6) return m.reply('⚠️ Maksimum durasi video 6 detik!');
        m.reply('⏳ Sedang membuat stiker dari video...');
        let media = await q.download();
        let encmedia = await conn.sendVideoAsSticker(m.chat, media, m, {
            packname,
            author
        });
        await fs.unlinkSync(encmedia);

    } else {
        throw `⚠️ Kirim atau reply gambar/video dengan caption *${usedPrefix + command}*\n📹 Durasi video maksimal 6 detik\n\n📌 Untuk ubah watermark, gunakan: *.setwm*`;
    }
};

handler.help = ['sticker'];
handler.tags = ['sticker'];
handler.command = /^(stiker|sticker|s)$/i;
handler.limit = true;

module.exports = handler;