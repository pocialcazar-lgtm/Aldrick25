// 📦 Plugin: fun-pantun.js
// 🔖 LuccaneXz Official

let handler = async (m, { conn }) => {
  const pantun = [
    "Burung nuri di atas dahan,\nTerbang ke hutan membawa pesan,\nHati ini selalu tertahan,\nMenunggumu dengan penuh harapan.",
    "Air tenang menghanyutkan,\nAir deras memecah batu,\nJangan sering memberikan harapan,\nKalau akhirnya ingin pergi satu-satu.",
    "Ke pasar beli semangka,\nTidak lupa beli pepaya,\nKalau kamu sedang luka,\nSenyum aja, biar bahagia.",
    "Burung elang terbang tinggi,\nMembawa harapan dalam hati,\nKalau kamu memang pergi,\nJangan lupa kembali lagi.",
    "Satu dua makan roti,\nTiga empat minum teh,\nKalau kamu ada di hati,\nJangan buat aku resah.",
    "Jalan-jalan ke kota Solo,\nNaik becak keliling kota,\nKamu itu selalu ngeluh molo,\nPadahal aku sabar banget lho katanya.",
    "Mentari pagi bersinar cerah,\nBurung berkicau penuh ceria,\nCintaku padamu sungguh megah,\nTulus dan tanpa pura-pura.",
    "Bunga mawar bunga melati,\nIndah dipandang setiap hari,\nJika kamu masih sendiri,\nBoleh deh jadi kekasih hati.",
    "Makan soto di pinggir jalan,\nTambah sambal tambah sedap,\nKalau rindu sudah datang,\nHati ini jadi gelisah banget.",
    "Hujan turun rintik-rintik,\nBikin jalan jadi licin,\nJangan bilang aku pelit,\nAku cuma hemat dikit.",
    "Makan durian jangan banyak,\nNanti perut bisa panas,\nKalau cinta sudah melekat,\nLDR pun jadi manis.",
    "Malam minggu gak kemana-mana,\nDi rumah aja baca cerita,\nMeski sendiri gak ada yang punya,\nAku tetap setia pada cita-cita.",
    "Pagi hari minum kopi,\nDitemani roti bakar keju,\nKalau kamu gak peduli,\nNanti nyesel loh ujung-ujungnya rindu.",
    "Mancing ikan di sungai besar,\nTarik pancing dengan semangat,\nCintaku ini benar-benar besar,\nJangan disia-siakan begitu saja.",
    "Naik kuda ke tengah padang,\nSambil membawa sepucuk surat,\nHatiku tak pernah tenang,\nKalau kamu lama tak menyurat.",
    "Burung hantu terbang malam,\nMencari makan hingga pagi,\nKalau kamu suka diam-diam,\nNanti direbut orang, rugi sendiri.",
    "Beli bakso di pinggir jalan,\nTambahin sambal biar mantap,\nKalau cinta sudah kedaluwarsa,\nBisa basi, terus hilang harap.",
    "Naik sepeda roda dua,\nKeliling kampung tanpa lelah,\nKalau kamu sedang gundah gulana,\nCurhat aja, aku siap pasang telinga.",
    "Menanam jagung di ladang luas,\nDisiram pagi dan sore,\nCintaku ini jelas dan tegas,\nBukan buat main-main semata.",
    "Di taman banyak bunga mekar,\nWarna-warni bikin senang hati,\nCintaku padamu tak pernah pudar,\nMeski waktu terus berganti.",
    "Ikan hiu makan pepaya,\nPepayanya manis dari Surabaya,\nKalau rindu udah melanda,\nCuma kamu yang bisa bikin reda.",
    "Bintang terang di malam kelam,\nMenemani hati yang kesepian,\nKalau kamu memang sayang,\nBilang aja, jangan pura-pura diam.",
    "Ke pantai lihat ombak berlari,\nMain pasir sambil nyantai,\nKalau kamu hadir tiap hari,\nHidupku pasti lebih damai.",
    "Matahari terbit dari timur,\nHangatkan bumi setiap pagi,\nKamu bagaikan pelipur,\nDalam hidup yang penuh misteri.",
    "Tidur siang di atas tikar,\nDitemani angin semilir lembut,\nKalau kamu sudah sadar,\nJangan bikin hatiku cemburu melulu."
  ];

  let hasil = pantun[Math.floor(Math.random() * pantun.length)];
  conn.sendMessage(m.chat, { text: hasil }, { quoted: m });
};

handler.command = /^pantun$/i;
handler.tags = ['random'];
handler.help = ['pantun'];
handler.limit = true;

module.exports = handler;