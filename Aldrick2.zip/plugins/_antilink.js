module.exports = {
  name: 'antilinkkick',
  async before(m, { conn, isAdmin, isBotAdmin, isOwner }) {
    if (!m.isGroup) return
    const chat = global.db.data.chats[m.chat]
    if (!chat.antilinkkick) return
    const regex = /https?:\/\/[^\s]+/gi
    if (regex.test(m.text) && !isAdmin && !isOwner && isBotAdmin) {
      await conn.sendMessage(m.chat, {
        text: `🚫 *Link Terdeteksi!*\n@${
          m.sender.split('@')[0]
        } akan dikeluarkan.`,
        mentions: [m.sender]
      })
      await conn.groupParticipantsUpdate(m.chat, [m.sender], 'remove')
    }
  }
}