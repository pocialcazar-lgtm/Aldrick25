/*
 * 📦 Plugin: menu.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * 🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
 * ⚠️ Jangan hapus watermark ini.
*/

/*
 * 📦 Plugin: menu.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * 🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
 * ⚠️ Jangan hapus watermark ini.
*/

const moment = require('moment-timezone');

let handler = async (m, { conn, command }) => {
  const name = m.pushName || 'Kak';
  const waktu = moment().tz('Asia/Jakarta').format('HH:mm:ss');
  const totalfitur = Object.keys(global.plugins).filter(name => !global.plugins[name].disabled).length;
  const thumb = 'https://files.catbox.moe/5bn2ys.jpg';

  if (command === 'menu') {
    let teks = `
𓆩ᥫ᭡𓆪 Aldrick_Bot 𓆩ᥫ᭡𓆪
        *MENU UTAMA*
━━━━━━━━━━━━━━━━━━━━

📌 .allmenu – Lihat semua fitur
📌 .owner – Kontak pemilik bot
📌 .infobot – Status & info bot
📌 .donasi – Dukung bot ini

━━━━━━━━━━━━━━━━━━━━
⏰ ${waktu} | Total fitur: ${totalfitur}
👤 Hai ${name}, ketik *.allmenu* untuk semua fitur!
    `.trim();
    return conn.sendFile(m.chat, thumb, 'menu.jpg', teks, m);
  }

  // Allmenu
  let categorized = {};

  for (let name in global.plugins) {
    let plugin = global.plugins[name];
    if (!plugin.help || plugin.disabled) continue;

    let tags = plugin.tags || ['uncategorized'];
    for (let tag of tags) {
      if (!categorized[tag]) categorized[tag] = [];

      // Filter command yang terlalu panjang agar tidak merusak tampilan
      for (let cmd of plugin.help) {
        if (typeof cmd === 'string' && cmd.length < 32) {
          categorized[tag].push(`• .${cmd}`);
        }
      }
    }
  }

  let teks = `
𓆩ᥫ᭡𓆪 Aldrick_Bot 𓆩ᥫ᭡𓆪
         *ALL MENU*
━━━━━━━━━━━━━━━━━━━━
`.trimStart();

  for (let tag in categorized) {
    if (categorized[tag].length === 0) continue;
    teks += `\n*⫹⫺ 「 ${tag.toUpperCase()} 」*\n`;
    teks += categorized[tag].join('\n') + '\n';
  }

  teks += `
━━━━━━━━━━━━━━━━━━━━
📌 Total fitur: ${totalfitur}
⏰ Waktu: ${waktu}
👤 Halo: ${name}
  `.trim();

  return conn.sendFile(m.chat, thumb, 'allmenu.jpg', teks, m);
};

handler.help = ['menu', 'allmenu'];
handler.tags = ['main'];
handler.command = ['menu', 'allmenu'];

module.exports = handler;