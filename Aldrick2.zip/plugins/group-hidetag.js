/*
 * 📦 Plugin: group-hidetag.js
 * 🔖 LuccaneXz Official
 * 👥 Xz Team Community
 * 🔗 https://whatsapp.com/channel/0029VanGZ6lEVccMmymNzv17
 * ⚠️ Jangan hapus watermark ini.
*/

let handler = async (m, { conn, text, usedPrefix, command, participants }) => {
  const q = m.quoted || m;
  const mime = (q.msg || q).mimetype || q.mediaType || '';
  text = text || q.text || q.caption || q.description || '';

  if (!text && !mime) {
    throw `📌 Contoh:\n${usedPrefix + command} Halo semua!\n\nAtau balas gambar/video/audio/stiker + caption.`;
  }

  const mentionList = participants.map(u => u.id);

  // Kontak palsu
  const fakeContact = {
    key: {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      id: "Hidetag"
    },
    message: {
      contactMessage: {
        displayName: "WhatsApp Bot",
        vcard: `BEGIN:VCARD\nVERSION:3.0\nFN:Bot WhatsApp\nTEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nEND:VCARD`
      }
    }
  };

  const quoted = m.quoted ? m.quoted.fakeObj : fakeContact;

  if (/image|video|audio/.test(mime)) {
    let media = await q.download?.();
    if (!media) throw '⚠️ Gagal mengunduh media.';

    const mediaType = mime.includes('image') ? 'image'
                      : mime.includes('video') ? 'video'
                      : 'audio';

    const mediaMsg = {
      [mediaType]: media,
      mentions: mentionList
    };

    if (mediaType === 'audio') {
      mediaMsg.mimetype = 'audio/mpeg';
    } else {
      mediaMsg.caption = text;
    }

    await conn.sendMessage(m.chat, mediaMsg, { quoted });

  } else if (/sticker/.test(mime)) {
    let media = await q.download?.();
    if (!media) throw '⚠️ Gagal mengunduh stiker.';

    await conn.sendMessage(m.chat, { sticker: media, mentions: mentionList }, { quoted });

  } else {
    await conn.sendMessage(m.chat, { text, mentions: mentionList }, { quoted });
  }
};

handler.help = ['hidetag <teks / balas media>'];
handler.tags = ['group'];
handler.command = /^(hidetag|ht|h)$/i;

handler.group = true;
handler.admin = true;
handler.botAdmin = true;

module.exports = handler;