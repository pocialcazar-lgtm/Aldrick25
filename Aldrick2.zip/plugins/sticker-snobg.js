const fs = require('fs');
const axios = require('axios');

let handler = async (m, { conn, usedPrefix, command }) => {
  let q = m.quoted ? m.quoted : m;
  let mime = (q.msg || q).mimetype || '';
  
  if (!mime) throw `⚠️ Balas gambar dengan perintah *${usedPrefix + command}*`;

  if (!/image\/(jpe?g|png)/.test(mime)) {
    throw '⚠️ File harus berupa gambar .jpg atau .png\nJangan kirim stiker .webp';
  }

  let media = await q.download();
  if (media.length > 2 * 1024 * 1024) throw '⚠️ Ukuran gambar terlalu besar. Maks 2MB.';

  m.reply('⏳ Menghapus background...');

  try {
    let { data } = await axios.post(`https://api.botcahx.eu.org/api/tools/removebg?apikey=${btc}`, media, {
      headers: {
        'Content-Type': 'image/jpeg' // atau image/png
      },
      responseType: 'arraybuffer'
    });

    let buffer = Buffer.from(data);
    let path = `./tmp/nobg_${Date.now()}.png`;
    fs.writeFileSync(path, buffer);

    let sticker = await conn.sendImageAsSticker(m.chat, buffer, m, {
      packname: global.packname,
      author: global.author
    });
    
    await fs.unlinkSync(path);
  } catch (e) {
    console.log(e);
    throw `⚠️ Gagal membuat stiker tanpa background.

• Pastikan:
- API aktif dan valid
- Gambar < 2MB
- Gambar *bukan* file .webp
- Kirim gambar biasa, jangan stiker.`;
  }
};

handler.help = ['snobg'];
handler.tags = ['sticker'];
handler.command = /^snobg$/i;
handler.limit = true;
module.exports = handler;