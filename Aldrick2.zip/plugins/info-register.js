const { createHash } = require('crypto')

let Reg = /\|?(.*)([.|] *?)([0-9]+)([.|] *?)(\w{2,15})$/i

let handler = async function (m, { text, usedPrefix }) {
  const user = global.db.data.users[m.sender]

  if (user.registered)
    throw `🚫 *Kamu sudah terdaftar!*\nUntuk daftar ulang, gunakan:\n👉 *${usedPrefix}unreg*`

  if (!Reg.test(text))
    throw `
❌ *Format Salah!*

📌 Gunakan format berikut:
*${usedPrefix}daftar* nama.umur.gender

✒️ Contoh:
• *${usedPrefix}daftar Luccane.25.cowok*
• *${usedPrefix}daftar Anna.18.cewek*

🔠 Gender yang dikenali:
• cowok / cewek
• co / ce
• cwok / cwk
`.trim()

  let [_, name, __, age, ___, genderRaw] = text.match(Reg)

  if (!name) throw '❌ Nama tidak boleh kosong.'
  if (!age) throw '❌ Umur tidak boleh kosong.'
  if (!genderRaw) throw '❌ Gender tidak boleh kosong.'

  age = parseInt(age)
  if (isNaN(age)) throw '❌ Umur harus berupa angka!'
  if (age < 5) throw '👶 Bayi bisa ngetik?'
  if (age > 120) throw '🧓 Umur terlalu tua!'

  const genderMap = {
    'laki-laki': 'laki-laki',
    'cowok': 'laki-laki',
    'cwok': 'laki-laki',
    'co': 'laki-laki',
    'pria': 'laki-laki',
    'lelaki': 'laki-laki',
    'perempuan': 'perempuan',
    'cewek': 'perempuan',
    'cwk': 'perempuan',
    'ce': 'perempuan',
    'ciwi': 'perempuan',
    'wanita': 'perempuan'
  }

  let gender = genderMap[genderRaw.toLowerCase()]
  if (!gender)
    throw `
❌ *Gender tidak dikenali!*

💡 Gunakan salah satu:
• cowok / cewek
• co / ce
• cwok / cwk
`.trim()

  // Simpan data ke database
  user.name = name.trim()
  user.age = age
  user.gender = gender
  user.regTime = +new Date()
  user.registered = true

  const sn = createHash('md5').update(m.sender).digest('hex')

  await m.reply(`
🎉 *Pendaftaran Berhasil!*

╭───〔 👤 DATA PENGGUNA 〕───
│ 📛 Nama    : ${name}
│ 🎂 Umur    : ${age} tahun
│ 🚻 Gender  : ${gender}
│ 🆔 Serial  : ${sn}
╰────────────────────────

✅ Sekarang kamu bisa gunakan perintah:
*.profile* untuk melihat status akunmu.
`.trim())
}

handler.help = ['daftar <nama>.<umur>.<gender>']
handler.tags = ['info']
handler.command = /^(daftar|reg(ister)?)$/i

module.exports = handler