const fs = require('fs')
const path = require('path')
const moment = require('moment')

const dir = './database'
const file = path.join(dir, 'sewa.json')

let handler = async (m, { conn, args }) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir)
  if (!fs.existsSync(file)) fs.writeFileSync(file, '[]')

  const data = JSON.parse(fs.readFileSync(file))

  let id = ''
  let durasi = ''

  if (args.length === 1 && m.chat.endsWith('@g.us')) {
    id = m.chat
    durasi = args[0]
  } else if (args.length === 2) {
    id = args[0]
    durasi = args[1]
  } else {
    return m.reply('❌ Format salah.\n\nContoh:\n.addsewa 120xxxx@g.us 30\n.addsewa 30 (dalam grup)\n.addsewa permanent')
  }

  let name = '(Tanpa Nama)'
  try {
    let metadata = await conn.groupMetadata(id)
    name = metadata.subject || name
  } catch (e) {
    console.log('⚠️ Tidak bisa ambil nama grup:', e)
  }

  let expired
  if (durasi.toLowerCase() === 'permanent') {
    expired = 'PERMANENT'
  } else if (!isNaN(durasi)) {
    expired = moment().add(Number(durasi), 'days').valueOf()
  } else {
    return m.reply('❌ Durasi tidak valid.')
  }

  const existing = data.find((d) => d.id === id)
  if (existing) {
    existing.expired = expired
    existing.name = name
  } else {
    data.push({ id, name, expired })
  }

  fs.writeFileSync(file, JSON.stringify(data, null, 2))
  m.reply(`✅ Grup *${name}* (${id}) berhasil disimpan!\n🕒 Durasi: ${durasi.toLowerCase() === 'permanent' ? 'PERMANENT' : durasi + ' hari'}`)
}

handler.command = /^addsewa$/i
handler.owner = true
module.exports = handler