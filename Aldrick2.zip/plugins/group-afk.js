let handler = async (m, { text }) => {
  let user = global.db.data.users[m.sender];
  user.afk = +new Date;
  user.afkReason = text;

  let tagUser = '@' + m.sender.split('@')[0];
  let alasan = text ? `📋 Alasan: ${text}` : '📋 Tanpa alasan';

  m.reply(`
🛌 *AFK Aktif!*
${tagUser} sekarang sedang AFK.
${alasan}
⌛ Mulai: Sekarang
  `.trim(), false, { mentions: [m.sender] });
};

handler.help = ['afk [alasan]'];
handler.tags = ['group'];
handler.command = /^afk$/i;

module.exports = handler;