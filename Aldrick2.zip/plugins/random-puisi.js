// 📦 Plugin: fun-puisi.js
// 🔖 LuccaneXz Official

let handler = async (m, { conn }) => {
  const puisi = [
    `Dalam hening malam aku menatap langit\nRibuan bintang seakan tahu rahasia hati\nNamamu terukir di relung paling dalam\nTak bisa kuhapus, tak bisa kulupa`,
    
    `Kau hadir bagai mentari pagi\nMenghangatkan jiwa yang beku dan sunyi\nSetiap senyummu meneduhkan hati\nSetiap tatapanmu membuatku berarti`,

    `Tak harus bersuara untuk saling memahami\nCukup diam namun hati berbicara\nKita berjalan di jalan yang sama\nMeski tak saling menggenggam tangan`,

    `Jatuh cinta bukan soal logika\nIa datang tanpa aba-aba\nTiba-tiba kau jadi segalanya\nTanpa tahu kapan mulainya`,

    `Aku adalah hujan yang kau rindukan\nMeski sering kau keluhkan\nTapi tanpaku, hatimu kering\nDan harimu kehilangan sejuk yang menenangkan`,

    `Kita adalah dua rindu\nYang saling mencari arah pulang\nMeski waktu tak berpihak\nKita tetap saling menunggu`,

    `Jika cinta adalah luka\nMaka biarlah aku terluka\nAsal aku tahu itu darimu\nBukan dari angin yang lewat tanpa rasa`,

    `Tak ada kata yang cukup menggambarkan\nBagaimana hati ini terpaut padamu\nSetiap detik berlalu, namamu berbisik\nDi sela napas dan denyut nadi`,

    `Kau adalah kata yang tak mampu aku tulis\nDalam puisi yang tak pernah habis\nKarena hatiku telah kau isi\nDengan cinta yang tak terganti`,

    `Di antara malam dan kesepian\nAda nama yang kusebut dalam diam\nTak lain adalah kamu\nYang diam-diam aku rindukan terus-menerus`,

    `Aku tak ingin janji-janji indah\nCukup kau hadir dengan tulus\nKarena kehadiranmu adalah puisi\nYang tak butuh banyak kata untuk dimengerti`,

    `Di pelupuk rindu aku terdiam\nMemandang bayanganmu di pelangi senja\nTak peduli jarak dan waktu\nAku mencintaimu dalam sunyi yang panjang`,

    `Jika esok kita tak lagi bersama\nSimpanlah satu bait puisi ini\nAgar kau tahu, pernah ada hati\nYang mencintaimu tanpa syarat, tanpa jeda`
  ];

  let hasil = puisi[Math.floor(Math.random() * puisi.length)];
  conn.sendMessage(m.chat, { text: hasil }, { quoted: m });
};

handler.command = /^puisi$/i;
handler.tags = ['random'];
handler.help = ['puisi'];
handler.limit = true;

module.exports = handler;