const fs = require('fs')
const path = require('path')

const dir = './database'
const file = path.join(dir, 'sewa.json')

let handler = async (m, { conn, args }) => {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir)
  if (!fs.existsSync(file)) fs.writeFileSync(file, '[]')

  const data = JSON.parse(fs.readFileSync(file))

  const id = m.chat.endsWith('@g.us') ? m.chat : args[0]
  if (!id || !id.endsWith('@g.us')) {
    return m.reply('❌ ID grup tidak valid.\nContoh: .delsewa 120xxxx@g.us')
  }

  const target = data.find(d => d.id === id)
  if (!target) return m.reply('⚠️ Grup tidak ditemukan di database sewa.')

  let name = target.name || id
  try {
    const metadata = await conn.groupMetadata(id)
    name = metadata.subject || name
  } catch (e) {
    // Tidak bisa ambil metadata? Lewat, pakai ID aja.
  }

  const updated = data.filter(d => d.id !== id)
  fs.writeFileSync(file, JSON.stringify(updated, null, 2))

  m.reply(`✅ Grup *${name}*\n🆔 ID: ${id}\nberhasil dihapus dari database sewa.`)
}

handler.command = /^delsewa$/i
handler.owner = true
module.exports = handler